# Galaxy Gamez Telegram Poster Bot — Full Project Handoff

## What this is
A Telegram bot system for Josh (Galaxy Gamez brand, Benin City, Nigeria) that
auto-posts PPSSPP/mobile game download links from a Blogger feed to Telegram
channels, plus a full command bot, multi-user support, monetization, and
referral/giveaway systems. Runs 100% free (GitHub Actions + Render free tier
+ UptimeRobot free tier — no paid hosting).

## Full feature list (confirmed + built)
1. **Posting engine** — pulls from a Blogger RSS feed, posts image+caption to
   Telegram channels, strictly sequential (oldest→newest), loops back to
   start only after the whole feed is exhausted. 3 unique posts per channel
   every 3 hours. Per-channel history tracking (a failure on one channel
   never causes a repeat on another).
2. **Post caption format** (exact, do not deviate — Josh designed this):
   ```
   ❏ 𝐆𝐀𝐌𝐄 𝐍𝐀𝐌𝐄: {TITLE}

   ╭➤ 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃 👇👇
   │ {link}
   │
   ├➤ 𝐏𝐀𝐒𝐒𝐖𝐎𝐑𝐃: 𝐍𝐎𝐍𝐄
   │
   ├➤ 𝐌𝐎𝐑𝐄 𝐆𝐀𝐌𝐄𝐒 👇
   │               https://galaxygamings.blogspot.com
   │
   ├➤ 𝐉𝐎𝐈𝐍 𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌
   │ https://t.me/GALAXYGAMEZ01
   │
   ├➤ 𝐉𝐎𝐈𝐍 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏 𝟏
   │ https://whatsapp.com/channel/0029Vb46RraF6smzVwGhZL2H
   │
   ╰➤ 𝐉𝐎𝐈𝐍 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏 𝟐
      https://whatsapp.com/channel/0029Vb56sG2IHphDA7uhWJ3C

   ┏━━━━━━━━━━━━━━━┓
      𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘: 𝙂𝘼𝙇𝘼𝙓𝙔 𝙂𝘼𝙈𝙀𝙕
   ┗━━━━━━━━━━━━━━━┛
   ```
   No brackets around game name (removed on request). No changes to the
   WhatsApp/Telegram/website links unless Josh gives new ones.
3. **Reply-keyboard commands** — every command has a tappable button, max
   2 buttons per row (3-in-a-row was rejected as ugly/hard to tap).
4. **Admin vs public command split**:
   - Admin only: Reset History, Logs, global Pause/Resume, Broadcast, Users list
   - Public: Post Now, Refresh, Skip, Test, Stats, Channels, Add Channel,
     Add Blog, pause/resume own channel only
5. **Force-join gate** — nobody can use ANY command until they've joined:
   - https://t.me/GALAXYGAMEZ01 (@GALAXYGAMEZ01)
   - https://t.me/galaxygamez02 (@galaxygamez02)
   - https://t.me/GALAXYGAMEZCHAT (@GALAXYGAMEZCHAT)
   - https://t.me/galaxygamezchat2 (@galaxygamezchat2)
   Checked via Telegram getChatMember on every message; shows join buttons +
   an "I've Joined" recheck button if any are missing.
6. **Multi-user self-service** — any Telegram user can DM the bot, add their
   own channel (bot must be admin there), add their own Blogger feed URL,
   and set **their own posting interval** — NOT locked to Josh's 3-hour
   cycle. Each channel has its own schedule, independent of everyone else's.
   **NOT YET BUILT** — current code still hardcodes a single global 3hr
   cycle for all channels via one GitHub Actions cron. Needs to change to:
   each channel stores its own `interval_hours` + `last_posted_at`, and the
   posting engine runs more frequently (e.g. every 30–60 min) and only
   posts to a given channel if enough time has passed since its own last
   post. This is a required fix before Step 2, not optional polish.
7. **Admin broadcast** — send an ad/promo to every connected channel at once
   (Josh's monetization lever — paid promos, since the bot itself is free).
8. **Delete-detection strike/ban system** — if a user deletes a broadcast
   post within 4 hours of it being sent, their channel is auto-removed and
   they get a strike. 3 strikes = permanent ban from ever adding a channel
   again. Users are told this upfront (onboarding + help text).
9. **Credits line** — "Credits: @galaxygamezsupport" (styled, boxed) appears
   in bot messages (help, onboarding, strike/ban notices) — NOT in the post
   caption footer, which stays "POWERED BY: GALAXY GAMEZ".

## IN PROGRESS / NOT YET BUILT (next priorities, in order)
### Step 2a — Per-channel custom posting interval — ✅ BUILT
- Each channel picks its own posting frequency when added: Hours (1/3/6/12/24)
  or Days (2/3/5/7), chosen via inline buttons at the end of onboarding.
- Stored per channel as `interval_hours` + `last_posted_at` in `users.json`.
- `main.py` checks each channel individually every run: only posts if
  `now - last_posted_at >= interval_hours`.
- `post.yml` cron changed from every 3hrs to hourly (`0 * * * *`) so the
  1-hour option is actually honored; each channel still only fires on its
  own chosen schedule.
- Josh's own 6 channels default to `interval_hours: 3` unless he changes it.

### Step 2 — "Gemz" currency + subscription system
- New users get a **24-hour free trial** on signup (enough posting time to
  test before paying).
- When trial/balance runs out, that channel's auto-posting auto-pauses with
  a notice to subscribe.
- In-bot currency, provisionally named **"Gemz"** (💎) — confirm name with
  Josh, he may want something else.
- Payment flow: user taps Subscribe → bot shows Josh's OPay details
  (Bank: OPAY, Account: 9071662919, Name: Josh Ehimika-Irhiemi) → user sends
  a screenshot as proof → **bot auto-forwards the screenshot + user info
  straight to Josh's admin chat, no DM required from the user** → Josh
  manually verifies the bank alert → Josh runs an admin command (e.g.
  `/credit <user_id> <amount>`) → user's Gemz balance updates + they're
  notified.
- Subscription plans (weekly/monthly/yearly) cost Gemz — exact prices not
  yet defined by Josh, build the framework so prices live in `config.py`
  and are easy to edit later.

### Step 3 — Referral + Giveaway system
- Every user gets a **unique referral link** (e.g.
  `https://t.me/BOTUSERNAME?start=REF<code>`), viewable anytime from the bot.
- When someone joins via a referral link, passes the force-join gate, AND
  adds a channel — **both** the referrer and the new user get equal Gemz.
- **Redeem/giveaway codes**: Josh generates a code from the admin side for a
  *specific* user (he searches for them, picks an amount, bot generates a
  code locked to that user's ID). A "🎁 Redeem" button lets users enter a
  code. Codes must be single-use and tied to one user ID so they can't be
  shared/stolen/brute-forced by other users.
- Needs a better in-chat name than "currency" for user-facing text (Josh's
  words) — call it "Gemz" (or whatever gets confirmed) consistently, never
  the generic word "currency" in user-facing messages.

## Architecture (current, working, free)
- **Posting engine** (`main.py`) — currently runs on **GitHub Actions**,
  cron every 3 hours (`0 */3 * * *`), posts to all active channels. **This
  is Josh's own interval, not a rule for every user** — each connected
  channel needs its own configurable interval (see Step 2a below), which
  means the engine needs to run more frequently (e.g. every 30 min) and
  check each channel's own `last_posted_at` + `interval_hours` before
  deciding to post, rather than posting to everyone on one fixed clock.
  Commits updated `users.json`/`stats.json`/`last_run_log.txt` back to the
  repo via git either way.
- **Command bot** — originally ran on GitHub Actions every 5 minutes
  (`commands.yml`), which caused a frustrating reply delay. **Being migrated
  to a Render free web service** (`bot_server.py`) for near-instant replies:
  Flask app + a background thread doing Telegram long-polling every ~2
  seconds. Render's free tier sleeps after 15 min idle, so an external free
  pinger (UptimeRobot) hits the Render URL every 5 min to keep it awake.
  `commands.yml`'s schedule was disabled (kept as manual-trigger-only backup)
  once Render took over, to avoid both systems double-handling updates.
- **Storage**: no external database. Everything is JSON files
  (`users.json`, `state.json`, `stats.json`, `broadcasts.json`) committed
  directly to the GitHub repo via git. Both GitHub Actions and Render read
  the SAME repo, so a `git_sync.py` module handles pull-before-read and
  push-after-write with retry-on-conflict, keeping both systems consistent.
- **No secrets in chat, ever** — bot tokens/API keys are only ever pasted
  directly into GitHub Secrets or Render environment variables, never sent
  in a Telegram or ChatGPT/Claude conversation.

## Full file list + purpose
| File | Purpose |
|---|---|
| `config.py` | All settings: channel IDs, blog feed URL, branding links, force-join list, POSTS_PER_CYCLE, strike limits, etc. |
| `storage.py` | JSON load/save helpers, user data model |
| `telegram_api.py` | Thin wrapper around Telegram Bot API calls |
| `caption.py` | Builds the exact post caption format above |
| `textstyle.py` | Unicode bold-text helper for consistent fonts across all bot messages |
| `main.py` | Posting engine — the 3-hour auto-post cycle |
| `bot_commands.py` | All command logic, keyboards, force-join, onboarding, broadcast, strikes |
| `git_sync.py` | Keeps Render + GitHub Actions in sync via git pull/push |
| `bot_server.py` | Always-on Render web service (replaces the 5-min command checker) |
| `.github/workflows/post.yml` | GitHub Actions: runs `main.py` every 3 hours |
| `.github/workflows/commands.yml` | GitHub Actions: manual-trigger-only backup for `bot_commands.py` |
| `requirements.txt` | Python deps: requests, feedparser, beautifulsoup4, flask, gunicorn |

## Environment variables / secrets needed
**GitHub repo Secrets** (Settings → Secrets and variables → Actions):
- `TELEGRAM_BOT_TOKEN`
- `ADMIN_CHAT_ID` (Josh's numeric Telegram user ID)
- `GITHUB_TOKEN` (auto-provided by GitHub Actions, no need to set manually
  for `post.yml`/`commands.yml`, but IS needed as an explicit Render env var)

**Render environment variables:**
- `TELEGRAM_BOT_TOKEN`
- `ADMIN_CHAT_ID`
- `GITHUB_TOKEN` (a GitHub Personal Access Token with repo write access —
  NOT the auto-provided Actions one, since Render is outside GitHub Actions)
- `GITHUB_REPOSITORY` (format: `username/repo-name`)

**Render start command:** `gunicorn bot_server:app --workers 1 --timeout 120`
(must stay `--workers 1` or the bot will double-poll Telegram and duplicate
every reply)

## Bugs already found and fixed (don't reintroduce these)
1. Old posting logic used `random.shuffle()` + only marked a post "done" if
   ALL channels succeeded — caused random-order posting and repeat floods
   when even one channel had a hiccup. Fixed with strict sequential order +
   per-channel success tracking.
2. `bot_commands.py` imported from a temporary filename (`main_new`) that no
   longer existed after a rename — caused silent crashes. Always
   double-check internal imports match actual filenames after any rename.
3. `POSTS_PER_CYCLE` was fixed in the posting loop logic but the matching
   `config.py` value wasn't re-sent to Josh — always ship config changes
   together with the logic that depends on them, as a complete set.
4. `git add broadcasts.json` failed when the file didn't exist yet (only
   created on first broadcast) — fixed by ensuring the file always exists
   on disk before any commit attempt.
5. Bot secrets (`TELEGRAM_BOT_TOKEN`, `ADMIN_CHAT_ID`) were saved empty in
   GitHub Secrets despite Josh believing he'd set them — always sanity-check
   secret values are actually non-empty when debugging "no response" issues.

## Josh's stated preferences (apply throughout)
- Concise, direct communication. No long unnecessary explanations.
- Structure any build/task plan as **Step X of Y**.
- Professional tone in all bot-facing and user-facing text — not casual,
  not cringe, no run-on/unstyled walls of text. Consistent font/design
  language throughout (the bold-unicode style already established).
- Never share tokens/secrets in plain chat.
- Wants everything to remain 100% free to run.
